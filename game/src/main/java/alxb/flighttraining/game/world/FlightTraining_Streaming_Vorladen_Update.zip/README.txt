FlightTraining – früheres Vorladen und weiche Übergänge

INSTALLIEREN
1. ZIP entpacken.
2. Ein Terminal im entpackten Ordner öffnen und ausführen:
   python3 install_update.py
   Standardziel: dein Ordner ~/Project/FlightTraining.
   Für einen anderen Projektordner:
   python3 install_update.py "/Pfad/zu/FlightTraining"
3. In IntelliJ Gradle neu laden und das Projekt neu erstellen. Bei alten Build-Dateien:
   ./gradlew :game:clean :game:classes :desktop:classes
4. DesktopLauncher starten.

Das Skript kopiert Dateien einzeln, prüft ihre Prüfsummen und sichert die vorherigen Fassungen unter .streaming-update-backups im Projekt. Andere vorhandene Projektdateien bleiben erhalten. In FlightTraining.java wird nur der bekannte Abschnitt der Startvorbereitung angepasst; andere Änderungen an dieser Klasse bleiben erhalten. Das Skript ist mit Python ab 3.9 nutzbar.

Alternativ können die Dateien unter files/ einzeln gemäß ihrer Pfade übernommen werden. Es gehören sowohl die Java-Dateien als auch die Shader unter game/src/main/resources/MatDefs/WorldObjects dazu. Dieses kleine Update ist eine Ergänzung zum vorhandenen Projekt.

UMFANG
- 3D-Sichtweite maximal fünf Chunks = etwa 5 km, begrenzt durch eine kleinere Renderdistanz.
- Zusätzlich bis zu 2 km verborgene Vorbereitung und bis zu 20 Sekunden / 3 km Vorlauf in Flugrichtung.
- Zuerst vereinfachte Abdeckung im ganzen Sichtbereich, danach nähere Details.
- Mehrere begrenzte Hintergrundaufträge; auf Nachbarhöhen wartende Pläne blockieren andere Kacheln nicht.
- Weiches Einblenden und LOD-Wechsel über etwa 0,55 Sekunden, weicher Rand über 300 m.
- Flughafenmodelle werden ebenfalls früher vorbereitet und erst im Sichtbereich angezeigt.
- Der erste Start wartet auf eine ausreichend vorbereitete Umgebung. Bei leerem Terraincache kann dieser Ladevorgang länger dauern; die Anzeige zeigt den Fortschritt. Danach müssen Objekte nicht erst direkt vor dem Flugzeug vorbereitet werden.
- Außerhalb des 3D-Sichtbereichs bleibt das Terrain entsprechend der eingestellten Renderdistanz erhalten.

Getestet: neu kompilierte vollständige Projektkopie mit 43 Produktionsdateien, ohne alte Projektklassen/-ressourcen im Classpath; nativer Spielstart; Bewegung mit 300 m/s; kleinere Renderdistanz; Höhenwechsel; verborgene Vorladung; Ursprungwechsel; fehlende Nachbarhöhen; Ersatzmaterialien bei nicht unterstützter Überblendung.
