#!/usr/bin/env python3
"""Install streaming code/resources file by file; keep a backup and preserve other project files."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import shutil
import tempfile
import uuid


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description="FlightTraining: Vorlade-Update mit Sicherung installieren")
    parser.add_argument("project", nargs="?", default=str(Path.home() / "Project" / "FlightTraining"),
                        help="Projektordner mit settings.gradle (Standard: ~/Project/FlightTraining)")
    args = parser.parse_args()
    target = Path(args.project).expanduser().resolve()
    package = Path(__file__).resolve().parent
    payload = package / "files"
    manifest = json.loads((package / "manifest.json").read_text(encoding="utf-8"))
    main_path = "game/src/main/java/alxb/flighttraining/game/FlightTraining.java"
    required = ["settings.gradle", main_path,
                "game/src/main/java/alxb/flighttraining/game/world/NaturalObjectStreaming.java"]
    for name in required:
        if not (target / name).is_file():
            raise SystemExit("Kein passender FlightTraining-Projektordner: " + str(target) + " (fehlt: " + name + ")")
    old_gate = '        if(ready<9){hud.showLoading("Objekte im Startgebiet werden vorbereitet: "+ready+" / 9");return;}'
    new_gate = '''        int total=terrain.spawnObjectTotal(plane.getLocalTranslation());
        if(!terrain.isSpawnAreaReady(plane.getLocalTranslation())){
            hud.showLoading("Startumgebung wird vorgeladen: "+ready+" / "+total+" Kacheln");return;
        }'''
    writes = {}
    for name, expected in manifest["files"].items():
        source = (payload / name).resolve()
        destination = (target / name).resolve()
        if not source.is_relative_to(payload.resolve()) or not destination.is_relative_to(target):
            raise SystemExit("Ungültiger Dateipfad im Update: " + name)
        data = source.read_bytes()
        if digest(data) != expected:
            raise SystemExit("Update-Datei ist unvollständig oder verändert: " + name)
        if name == main_path:
            existing = destination.read_text(encoding="utf-8")
            if "terrain.isSpawnAreaReady(plane.getLocalTranslation())" in existing:
                continue
            if old_gate not in existing:
                raise SystemExit("Die Startvorbereitung in FlightTraining.java wurde verändert. Bitte den Abschnitt anhand der beigefügten Datei übernehmen; es wurden noch keine Projektdateien geändert.")
            data = existing.replace(old_gate, new_gate, 1).encode("utf-8")
        if destination.is_file() and destination.read_bytes() == data:
            continue
        writes[name] = data
    if not writes:
        print("Das Vorlade-Update ist bereits installiert.")
        return
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6]
    backup = target / ".streaming-update-backups" / stamp
    backup.mkdir(parents=True)
    created = []
    # Make every required backup before changing the first project file.
    for name in writes:
        destination = target / name
        if destination.exists():
            saved = backup / name
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(destination, saved)
        else:
            created.append(name)
    (backup / "manifest.json").write_text(json.dumps({"changed": list(writes), "new": created}, indent=2), encoding="utf-8")
    for name, data in writes.items():
        destination = target / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(dir=destination.parent, prefix=".streaming-", delete=False) as temp:
            temp.write(data)
            temporary = Path(temp.name)
        try:
            temporary.chmod(0o644)
            os.replace(temporary, destination)
        finally:
            temporary.unlink(missing_ok=True)
    print("Installiert:", len(writes), "Dateien in", target)
    print("Sicherung:", backup)
    print("Danach Gradle neu laden, das Projekt neu erstellen und DesktopLauncher starten.")


if __name__ == "__main__":
    main()
